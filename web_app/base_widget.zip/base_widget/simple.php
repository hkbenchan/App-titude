<?php
function listItems() {
	echo "listItems();\n";
}

function getItem($item) {
	echo "getItem(".$item.");\n";
}

function addItem($item) {
	echo "addItem(".$item.");\n";
}

function updateItem($item,$newItem) {
	echo "updateItem(".$item.",".$newItem.");\n";
}

function deleteItem($item) {
	echo "deleteItem(".$item.");\n";
}
?>
